#ifndef CSE167_RenderData_h
#define CSE167_RenderData_h

#include <iostream>

class DrawData
{
    
public:
    
    //Payload
    //Place any objects here that you want to pass to a draw() call
    
    DrawData(void);
    ~DrawData(void);
    
};

#endif
