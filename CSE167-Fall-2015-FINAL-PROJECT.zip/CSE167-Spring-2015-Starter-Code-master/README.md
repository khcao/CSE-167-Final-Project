# CSE167-Spring-2015-Starter-Code
Proposed Starter Code for the Spring 2015 offering of UCSD's CSE 167

For Setup and Build Instructions see: http://ivl.calit2.net/wiki/index.php/BasecodeCSE167S15
